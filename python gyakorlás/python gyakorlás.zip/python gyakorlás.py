import math

def páratlan(a):
    return a%3 == 1
