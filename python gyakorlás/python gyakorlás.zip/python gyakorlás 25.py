hősök = []


hős = None

while hős != '':
    hős = input('Írd ide egy hős nevét')
    if hős :
        hősök.append(hős)

print(hősök)    
