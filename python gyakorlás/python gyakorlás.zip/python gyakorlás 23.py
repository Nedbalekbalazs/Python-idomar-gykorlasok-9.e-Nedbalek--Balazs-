print('Ez a program a kedvenc mesehőseid nevét tárolja el. ')

print('Addig kérdezget, amíg úgy nem nyomsz Entert-t, hogy nem írsz elé semmit. ')

hős = None

while hős != '':
    hős = input('Írj egy hősnevet!')
