lovak = ['Ráró','Báró','Tipró','Káró']

while lovak != '':
    ló = input('Add meg a lovak színét!')
            
print(lovak)        
