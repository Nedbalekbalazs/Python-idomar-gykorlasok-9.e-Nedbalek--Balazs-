

for szám in range(10, 2):
    print(szám)
