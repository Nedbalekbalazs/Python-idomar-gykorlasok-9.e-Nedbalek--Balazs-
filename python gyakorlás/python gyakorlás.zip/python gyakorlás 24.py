Python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:01:18) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
====== RESTART: C:/Python3.5.2/python gyakorlás/python gyakorlás 23.py ======
Ez a program a kedvenc mesehőseid nevét tárolja el. 
Addig kérdezget, amíg úgy nem nyomsz Entert-t, hogy nem írsz elé semmit. 
Írj egy hősnevet!Pókember
Írj egy hősnevet!te
Írj egy hősnevet!jóska
Írj egy hősnevet!anyád  
Írj egy hősnevet!anyád                       
Írj egy hősnevet!
>>> 
====== RESTART: C:/Python3.5.2/python gyakorlás/python gyakorlás 23.py ======
Ez a program a kedvenc mesehőseid nevét tárolja el. 
Addig kérdezget, amíg úgy nem nyomsz Entert-t, hogy nem írsz elé semmit. 
Írj egy hősnevet!Te
Írj egy hősnevet!
>>> 
